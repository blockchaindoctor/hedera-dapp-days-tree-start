// TESTNET CREDENTIALS
const operator = {
	id: "0.0.2...",
	pb_key: "302...",
	pvkey: "302...",
};

export default operator;
