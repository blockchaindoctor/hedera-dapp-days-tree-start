import React from "react";
import operator from "../../config.js";
import { Client, AccountId, PrivateKey, TokenCreateTransaction } from "@hashgraph/sdk";

async function tokenCreateFcn() {
	//Configure the Hedera client...
	//Add code to create the HTS token...
}

export default tokenCreateFcn;
