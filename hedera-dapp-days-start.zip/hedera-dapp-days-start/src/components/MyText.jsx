import React from "react";

function MyText(props) {
	return (
		<div>
			<p className="sub-text">{props.text}</p>
		</div>
	);
}

export default MyText;
